import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'mypipe'
})
export class MypipePipe implements PipeTransform {

  transform(valor1:string, valor2:string): string {
     return "Resultado de "+valor1+" x "+valor2+" =" + parseInt(valor1) * parseInt(valor2);
  }

}
