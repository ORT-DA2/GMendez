import { Component, OnInit } from '@angular/core';
import { Student } from '../Models/student';
import { StudentService } from '../Services/student.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css'],
  providers: [StudentService]
})
export class StudentComponent implements OnInit {
  public student: Student;
  public vertical: Boolean;
  public fecha: Date;
  public studentId: String;

  public percent: number;

  constructor(
    private _route: ActivatedRoute,
    private _studentService: StudentService
  ) {

    this.studentId = '';
    this.student = <Student>{}; //new Student('M321', 'mariela', 'jimenez');
    this.vertical = true;
    this.fecha = new Date(2021, 9, 25);

    this.percent = 65;
  }

  ngOnInit(): void {
      this.studentId = this._route.snapshot.params['studentId'];
      this.student = this._studentService.GetStudent(this.studentId) || <Student>{};
  }

  public CambiarVista() {
    this.vertical = !this.vertical;
  }
}
