import { Injectable } from "@angular/core";

import {HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable, throwError } from 'rxjs';

import { Student } from "../Models/student";

@Injectable()
export class StudentRequestsService{


  private WEB_API_URL : string = 'http://localhost:47888/Api/Students';

  constructor(private _httpService: HttpClient) {  }


  public GetStudents():Observable<Array<Student>> {

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json'
      })
    };

    httpOptions.headers = httpOptions.headers.set('Authorization','39ea67c0-9076-41f0-b14d-0def4420dfa6');

    return this._httpService.get<Array<Student>>(this.WEB_API_URL, httpOptions);

  }
}
