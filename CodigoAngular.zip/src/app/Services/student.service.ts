import { Injectable } from "@angular/core";
import { Student } from '../Models/student';

@Injectable()
export class StudentService {

  private students: Array<Student>;

  constructor() {
    this.students = [
      new Student("XG321", "Juan", "Lopez"),
      new Student("PQ43", "Maria", "Fernandez"),
      new Student("TY325", "Francisca", "Ayala"),
      new Student("AH872", "Martin", "Lopez"),
      new Student("HAGS", "Ana", "Guitierrez"),
    ];
  }

  public GetStudents(): Array<Student> {
    return this.students;
  }

  public GetStudent(studentId: String) : Student | undefined {
    if (studentId != '') {
      return this.students.find(s => s.studentId.toUpperCase() == studentId.toUpperCase()) ;
    }
    return this.students[0]; //Por defecto devuelvo el primero de la lista
  }

}
