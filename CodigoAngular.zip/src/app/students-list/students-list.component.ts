/*
import { Component, OnInit } from '@angular/core';
import { Student } from '../Models/student';
import { StudentService } from '../Services/student.service';
import { Router } from '@angular/router';

//Implementacion ORIGINAL que  delega sobre un componente que retorna una lista Hard-Coded
///-------------------------------------------------------------------------------------
@Component({
  selector: 'app-students-list',
  templateUrl: './students-list.component.html',
  styleUrls: ['./students-list.component.css'],
  providers: [StudentService],
})
export class StudentsListComponent implements OnInit {
  public students: Array<Student>;
  public infoLevel: number;

  constructor(
    private _studentService: StudentService,
    private _router: Router
  ) {
    this.students = _studentService.GetStudents();
    this.infoLevel = 10;
  }

  ngOnInit(): void {}

  public ShowInfoLevel() {
    alert('El tipo de vista seleccionada es: ' + this.infoLevel);
  }

  public RedirectToStudent(studentId: String) {
    this._router.navigate(['/student', studentId]);
  }
}*/



//Implementacion que delega sobre un componente que accede a la API
///-------------------------------------------------------------------------------------
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Student } from '../Models/student';
import { Router } from '@angular/router';
import { StudentRequestsService } from '../Services/studentRequests.service';

import { /*Observable,*/ Subscription } from 'rxjs';

@Component({
  selector: 'app-students-list',
  templateUrl: './students-list.component.html',
  styleUrls: ['./students-list.component.css'],
  providers: [StudentRequestsService],
})
export class StudentsListComponent implements OnInit, OnDestroy {
  public students: Array<Student>;
  public infoLevel: number;

  subscription:Subscription = new Subscription();

  constructor(
    private _studentService: StudentRequestsService,
    private _router: Router
  ) {
    this.students = [];
    this.infoLevel = 10;
  }

  ngOnInit() {
    this.subscription = this._studentService.GetStudents()
    .subscribe(
      (students: Array<Student>) => {
        this.students = students;
      },
      ((error : any) => console.log(error))
    )
  }

  ngOnDestroy(){
    this.subscription.unsubscribe();
  }

  public ShowInfoLevel() {
    alert('El tipo de vista seleccionada es: ' + this.infoLevel);
  }

  public RedirectToStudent(studentId: String) {
    this._router.navigate(['/student', studentId]);
  }
}

