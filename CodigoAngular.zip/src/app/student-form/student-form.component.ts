import { Component, OnInit } from '@angular/core';
import { Student } from '../Models/student';

@Component({
  selector: 'app-student-form',
  templateUrl: './student-form.component.html',
  styleUrls: ['./student-form.component.css']
})
export class StudentFormComponent implements OnInit {

  public student:Student;

  constructor() {
    this.student = new Student("","","");
  }

  ngOnInit(): void {
  }

  onSubmit(){
    console.log(this.student);
  }

}
