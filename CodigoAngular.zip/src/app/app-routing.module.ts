import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { NotfoundComponent } from './notfound/notfound.component';
import { StudentFormComponent } from './student-form/student-form.component';

//ruteo "agregado a mano"
import { StudentComponent } from './student/student.component';
import { StudentsListComponent } from './students-list/students-list.component';

const routes: Routes = [
  //ruteo "agregado a mano"
  {path:'',component: HomeComponent},

  {path:'home', component: HomeComponent},
  {path:'student-new', component: StudentFormComponent},
  {path:'student', component: StudentComponent},
  {path:'student/:studentId', component: StudentComponent},
  {path:'student-list',component:StudentsListComponent},

  {path:'**', component:NotfoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
