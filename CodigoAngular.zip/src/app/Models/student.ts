export class Student {
  /*
    public studentId:string;
    public name:string;
    public lastName:string;

    constructor(studentId:string, name:string, lastName:string ){
      this.studentId = studentId;
      this.name = name;
      this.lastName = name;
    }
  */

  constructor
  (
    public studentId:string,
    public name:string,
    public lastName:string
  ){}
}
