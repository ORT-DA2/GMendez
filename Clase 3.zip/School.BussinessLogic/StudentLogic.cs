﻿using School.DomainObjects;
using School.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;

namespace School.BussinessLogic
{
    public class StudentLogic : ILogic<Student>
    {      
 
        public Student Add(Student s)
        {
            ObjectContainer.Students.Add(s);

            return s;
        }

        public void Remove(int id)
        {

        }

        public Student Update(int id, Student student)
        {
            var st = Get(id);
            if (st == null)
            {
                return null;
            }

            st.Name = student.Name;
            st.StudentId = student.StudentId;

            //Save
            return st;
        }

        public Student Get(int id)
        {
            var student = ObjectContainer.Students.Where(s => s.Id == id).FirstOrDefault();
            return student;
        }

        public IEnumerable<Student> GetAll()
        { 
            //Simulamos una excepcion par ver como se ve en Postman cuando no esta debidamente controlada
            ////throw new Exception("Excepcion que revela detalles de implementacion");
            return ObjectContainer.Students;
        }
    }
}
