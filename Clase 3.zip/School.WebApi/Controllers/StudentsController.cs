﻿using Microsoft.AspNetCore.Mvc;
using School.BussinessLogic;
using School.DomainObjects;
using School.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace School.WebApi.Controllers
{
    //[Route("api/[controller]")]
    [Route("api/Students")]
    [ApiController]
    public class StudentsController : ControllerBase
    {
        private readonly ILogic<Student> _logic;

        public StudentsController()
        {
            _logic = new StudentLogic();
        }

        // GET: api/<StudentController>
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                IEnumerable<Student> result = _logic.GetAll();
                var returnResult = Ok(result);
                return returnResult;
            }
            catch (Exception ex)
            {
                //Log de la excepcion
                return StatusCode(500, "generic_error");
            }
        }

        // GET api/<StudentController>/5
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            try
            {
                var student = _logic.Get(id);
                if (student == null)
                {
                    return NotFound(id); //Mas completo y mejor, seria devolver un objeto que incluya mas info, junto con el criterio de busqueda
                }
                return Ok(student);
            }
            catch (Exception ex)
            {
                //Log de la excepcion
                return StatusCode(500, "generic_error");
            }
        }


        [HttpGet("{id}/courses")]
        public string StudentCourses(int id)    
        {
            return $"Listamos todos los cursos a lo que el estudiante con Id {id} esta inscripto";
        }

        // POST api/<StudentController>
        [HttpPost]
        public void Post([FromBody] Student student)
        {
            _logic.Add(student);
        }

        // PUT api/<StudentController>/5
        [HttpPut()]
        public IActionResult Put([FromBody] Student studentPar)
        {
            var studentToUpdate = _logic.Update(studentPar.Id, studentPar);

            if (studentToUpdate == null)
            {
                return NotFound(studentPar.Id); //Mas completo y mejor, seria devolver un objeto que incluya mas info, junto con el criterio de busqueda
            }

            return Ok(studentToUpdate);

        }

        // DELETE api/<StudentController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
