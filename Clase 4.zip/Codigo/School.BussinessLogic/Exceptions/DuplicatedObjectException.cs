﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace School.BussinessLogic.Exceptions
{
    public class DuplicatedObjectException : Exception
    {
        public DuplicatedObjectException(string message) : base (message) { }
    }
}
