﻿using School.DomainObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace School.BussinessLogic
{
    public class ObjectContainer
    {
        //Esto es SOLAMENTE para salir del paso con el ejemplo.
        //NO SE DEBE HACER.  ** ESTA MAL!! **
        private static List<Student> _students = CreateStudents();
        private static List<Course> _courses = CreateCourses();
        public static List<Student> Students
        {
            get
            {
                return _students;
            }
        }

        public static List<Course> Courses
        {
            get
            {
                return _courses;
            }
        }

        private static List<Course> CreateCourses()
        {
            return new List<Course>()
            {
                new Course()
                {
                    Id = 1,
                    Name = "Ingenieria de Software Ágil 1",
                    Semester= 6
                },
                new Course()
                {
                    Id = 1,
                    Name = "Diseño de Aplicaciones 2",
                    Semester= 6
                },
                new Course()
                {
                    Id = 1,
                    Name = "Taller de Tecnologías 2",
                    Semester= 6
                },
                new Course()
                {
                    Id = 1,
                    Name = "Programación de Redes",
                    Semester= 6
                },
                new Course()
                {
                    Id = 1,
                    Name = "Machine Learning",
                    Semester= 6
                }
            };
        }

        private static List<Student> CreateStudents()
        {
            return new List<Student>()
            {
                new Student()
                {
                     Id = 1,
                     StudentId = "Ma001",
                     Name = "Maria"
                },
                new Student()
                {
                     Id = 2,
                     StudentId = "Ju002",
                     Name = "Juan"
                },
                new Student()
                {
                     Id = 3,
                     StudentId = "Er003",
                     Name = "Erika"
                }
            };
        }
    }
}
