﻿using School.BussinessLogic.Exceptions;
using School.DomainObjects;
using School.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;

namespace School.BussinessLogic
{
    public class StudentLogic : ILogic<Student>
    {
        private const string null_student = "Student object is null";

        public Student Add(Student s)
        {
            //Validamos que el objeto no sea null
            if (s == null)
            {
                //O tambien si determino que el objeto es invalido....
                throw new InvalidObjectException(null_student);
            }
            
            /* Nos interesa controlar el numero de estudiante, no permitiendo insertar duplicados.
             * Normalmente delegariamos este control a la base de datos pero POR EL MOMENTO estamos 
             * trabajando en memoria, asi que realizaremos el control a mano */
            if (ObjectContainer.Students.Any(x => x.StudentId == s.StudentId))
            {
                throw new DuplicatedObjectException($"A student with StudentId {s.StudentId} already exists.");
            }

            // Tener en cuenta que estamos recibiendo un objeto que contiene un Id, pero el Id deberia ser interno  (lo arreglaremos despues).
            // Hacemos un pequeno hack para generar un id:
            s.Id = ObjectContainer.Students.OrderBy(x => x.Id) //Ordeno por Id
                .Select(x => x.Id).FirstOrDefault() //Me quedo solo con el Id (Similar a una proyeccion en bases de datos)
                + 1;// y le sumo 1.

            ObjectContainer.Students.Add(s);

            return s;
        }

        //TODO: Cambiamos la definicion, tambien a nivel de la interfaz para poder saber que sucedio, retornando true o false
        public bool Remove(int id)
        {
            var st = Get(id);
            if (st == null)
            {
                return false;
            }

            ObjectContainer.Students.Remove(st);

            return true;
        }

        public Student Update(int id, Student s)
        {
            if (s == null)
            {
                throw new ArgumentNullException(null_student);
            }

            var st = Get(id);
            if (st == null)
            {
                return null;
            }

            //Independientemente del objeto que ya cargue en memoria por Id, verifico que no voy a generar un duplicado por StudentId
            if (ObjectContainer.Students.Any(x => x.StudentId == s.StudentId & x.Id != s.Id))
            {
                throw new DuplicatedObjectException($"Student with StudentId {s.StudentId} already exists.");
            }

            st.Name = s.Name;
            st.StudentId = s.StudentId;

            //Save
            return st;
        }

        public Student Get(int id)
        {
            var student = ObjectContainer.Students.Where(s => s.Id == id).FirstOrDefault();
            return student;
        }

        public IEnumerable<Student> GetAll()
        { 
            //Simulamos una excepcion par ver como se ve en Postman cuando no esta debidamente controlada
            ////throw new Exception("Excepcion que revela detalles de implementacion");
            return ObjectContainer.Students;
        }
    }
}
