﻿using Microsoft.AspNetCore.Mvc;
using School.BussinessLogic;
using School.BussinessLogic.Exceptions;
using School.DomainObjects;
using School.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace School.WebApi.Controllers
{
    //[Route("api/[controller]")]
    [Route("api/Students")]
    [ApiController]
    public class StudentsController : ControllerBase
    {
        private const string server_error = "Internal Server Error";

        private readonly ILogic<Student> _logic;

        //TODO: Modificamos el constructor para que reciba por parametro las dependencias que queremos inyectar
        public StudentsController(ILogic<Student> logic)
        {
            //En vez de instanciar, ahora directamente asignamos el argumento a la variable de instancia
            _logic = logic;
        }


        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                IEnumerable<Student> result = _logic.GetAll();
                var returnResult = Ok(result);
                return returnResult;
            }
            catch (Exception ex)
            {
                //Log de la excepcion
                return StatusCode(500, server_error);
            }
        }


        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            try
            {
                var student = _logic.Get(id);
                if (student == null)
                {
                    return NotFound(id); 
                }
                return Ok(student);
            }
            catch (Exception ex)
            {
                //Log de la excepcion
                return StatusCode(500, server_error);
            }
        }


        [HttpGet("{id}/courses")]
        public string StudentCourses(int id)
        {
            return $"Listamos todos los cursos a lo que el estudiante con Id {id} esta inscripto";
        }


        [HttpPost]
        public IActionResult Post([FromBody] Student student)
        {
            //TODO: Implementación nueva
            try
            {
                _logic.Add(student);
            }
            catch (ArgumentNullException nullex)
            {
                //Nos enviaron un objeto invalido. Puntualmente en este caso esta bien devolver el mensaje de la exception porque
                //no revela detalles de implementacion.
                return BadRequest(nullex.Message);
            }
            catch (DuplicatedObjectException dupex)
            {
                //Retornamos lo mismo que antes y esta Ok, pero de hecho es un caso distinto y conviene manejarlo por separado
                return BadRequest(dupex.Message);
            }
            catch (Exception ex)
            {
                //Si el error es cualquier otra cosa... retornamos un 500
                //En cualquier caso podriamos guardar log de la excepcion por ejemplo
                return StatusCode(500, server_error);
            }

            return Ok();
        }
    

        
        [HttpPut()]
        public IActionResult Put([FromBody] Student studentPar)
        {

            try
            {
                var studentToUpdate = _logic.Update(studentPar.Id, studentPar);
                if (studentToUpdate == null)
                {
                    return NotFound(studentPar.Id);
                }
                return Ok(studentToUpdate);
            }
            catch(ArgumentNullException nullex)
            {
                //Nos enviaron un objeto invalido. Puntualmente en este caso esta bien devolver el mensaje de la exception porque
                //no revela detalles de implementacion.
                return BadRequest(nullex.Message);
            }
            catch (DuplicatedObjectException dupex)
            {
                //Retornamos lo mismo que antes y esta Ok, pero de hecho es un caso distinto y conviene manejarlo por separado
                return BadRequest(dupex.Message);
            }
            catch (Exception ex)
            {
                //Si el error es cualquier otra cosa... retornamos un 500
                //En cualquier caso podriamos guardar log de la excepcion por ejemplo
                return StatusCode(500, server_error);
            }


        }


        //TODO: Implementacion nueva
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                var removed = _logic.Remove(id);
                if (removed)
                {
                    return Ok(id);
                }

                return NotFound(id);
            }
            catch (Exception ex)
            {
                return StatusCode(500, server_error);
            }
        }
    }
}
