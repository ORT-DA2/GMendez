﻿using Microsoft.AspNetCore.Mvc;
using School.BussinessLogic;
using School.DomainObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace School.WebApi.Controllers
{
    //[Route("api/[controller]")]
    [Route("api/Students")]
    [ApiController]
    public class StudentsController : ControllerBase
    {
        // GET: api/<StudentController>
        [HttpGet]
        public IActionResult Get()
        {
            StudentLogic logic = new StudentLogic();
            List<Student> result = logic.GetAll();
            var returnResult = Ok(result);
            return returnResult;
        }

        // GET api/<StudentController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }


        [HttpGet("{id}/courses")]
        public string StudentCourses(int id)
        {
            return $"Listamos todos los cursos a lo que el estudiante con Id {id} esta inscripto";
        }



        // POST api/<StudentController>
        [HttpPost]
        public void Post([FromBody] Student student)
        {
            StudentLogic logic = new StudentLogic();
            logic.Add(student);
        }

        // PUT api/<StudentController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<StudentController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
