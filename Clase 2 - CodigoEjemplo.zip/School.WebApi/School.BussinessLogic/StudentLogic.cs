﻿using School.DomainObjects;
using System;
using System.Collections.Generic;

namespace School.BussinessLogic
{
    public class StudentLogic
    {
        //Esto es SOLAMENTE para salir del paso con el ejemplo.
        //NO SE DEBE HACER.  ** ESTA MAL!! **
        public static List<Student> _students = CreateStudents();

        private static List<Student> CreateStudents()
        {
            return new List<Student>()
            {
                new Student()
                {
                     Id = 1,
                     StudentId = "Ma001",
                     Name = "Maria"                     
                },
                new Student()
                {
                     Id = 2,
                     StudentId = "Ju002",
                     Name = "Juan"
                },
                new Student()
                {
                     Id = 2,
                     StudentId = "Er003",
                     Name = "Erika"
                }
            };    
        }

        public List<Student> GetAll()
        {
            return _students;
        }

        public void Add(Student s)
        {
            _students.Add(s);
        }

    }
}
